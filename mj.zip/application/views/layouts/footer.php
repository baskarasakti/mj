<footer class="footer text-center"> Copyright © 2017 <a href="http://indiglob.com/">IndiGlobal</a>. All rights reserved. </footer>
