<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['username'] = 'Enter Your Username';
$lang['password'] = 'Enter Your Password';
$lang['remember'] = 'Remember Me';
$lang['forgot']	= 'Forgot Password?';
$lang['login']	= 'Log In';
$lang['login_error'] = 'Wrong Username or Password';



