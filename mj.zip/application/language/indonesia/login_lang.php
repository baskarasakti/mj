<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['username'] = 'Ketikkan username Anda';
$lang['password'] = 'Ketikkan kata kunci Anda';
$lang['remember'] = 'Ingatkan saya';
$lang['forgot']   = 'Lupa kata kunci?';
$lang['login'] 	  = 'Masuk';


